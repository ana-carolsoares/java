public class Baleia extends Mamifero {

    public Baleia(Integer peso) {
        super(peso, false);
    }
}
